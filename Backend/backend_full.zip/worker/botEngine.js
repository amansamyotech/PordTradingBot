const Binance = require('node-binance-api');
const User = require('../models/User');
const { saveTradeLog } = require('../services/tradeService');
require('dotenv').config();

async function runBotForUser(user) {
  const binance = new Binance().options({
    APIKEY: user.binanceApiKey,
    APISECRET: user.binanceApiSecret,
    useServerTime: true
  });

  try {
    const candles = await binance.candlesticks("BTCUSDT", "1m", null, { limit: 100 });
    const closes = candles.map(c => parseFloat(c[4]));
    const sma7 = closes.slice(-7).reduce((a, b) => a + b, 0) / 7;
    const sma25 = closes.slice(-25).reduce((a, b) => a + b, 0) / 25;
    const rsi = 30;

    if (sma7 > sma25 && rsi < 30) {
      const order = await binance.marketBuy("BTCUSDT", 0.001);
      await saveTradeLog(user._id, "BTCUSDT", order.fills[0].price, 'BUY');

      if (user.telegramEnabled) {
        const message = `📈 BUY executed at ${order.fills[0].price}`;
        await sendTelegram(user.telegramChatId, message);
      }
    }
  } catch (err) {
    console.error(err.message);
  }
}

async function startBotScheduler() {
  const users = await User.find({ botEnabled: true });
  setInterval(() => {
    users.forEach(user => runBotForUser(user));
  }, 60000); // every 1 min
}

module.exports = { startBotScheduler };
